# Captcha Generator 
A simple image captcha generator

### Prerequisites
1. Install the dependencies by executing the following command if needed:
   	pip install tk
	pip install Pillow
	pip install captcha
