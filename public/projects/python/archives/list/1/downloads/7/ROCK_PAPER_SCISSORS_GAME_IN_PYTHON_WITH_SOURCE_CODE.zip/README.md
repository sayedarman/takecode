#Requremnts
1: Packanges- tk.
#LISENSE
1: We Researve Editing,Modifying,etc.
2: If It works give the website link to your frindes!
#information
Creator: Sayed Arman.
Website: ~~~~
Discord: https://discord.gg/EmYyPpAmsy
Thanks-For-Downloding !