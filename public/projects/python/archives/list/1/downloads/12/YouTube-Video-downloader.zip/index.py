#imports
from pytube import YouTube #pip install pytube
try:
    #variables
    link = str(input("Link:"))
    youtube_1 =YouTube(link)
    videos= youtube_1.streams.filter(only_audio=True)
    vid =list(enumerate(videos))    
    print(youtube_1.title)
    print(youtube_1.thumbnail_url)
    for i in vid:
        print(i)
    print()
    strm= int(input("Enter:"))
    videos[strm].download()
    print('Video Successfully Downloaded.')
except SyntaxError:
    print('its,not an link !')    